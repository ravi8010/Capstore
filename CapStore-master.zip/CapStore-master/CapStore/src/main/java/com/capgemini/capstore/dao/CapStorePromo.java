package com.capgemini.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.capstore.beans.Promo;

public interface CapStorePromo extends JpaRepository<Promo, String>{

}
